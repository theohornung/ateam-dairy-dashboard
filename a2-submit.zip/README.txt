Course: cs400
Semester: Spring 2020
Project Name: ateam-dairy-dashboard

Team Members:
1. Theo Hornung, 002, tthornung@wisc.edu
2. Ethan Simonen, 002, esimonen@wisc.edu
3. Aidan Derocher, 001, aderocher@wisc.edu

No members were on the same xteam.

Notes: (tbd)
